"use client"

import { useState } from "react"
import { SidebarProvider, SidebarInset } from "@/components/ui/sidebar"
import { AdminSidebar, type AdminPage } from "./admin-sidebar"
import { AdminHeader } from "./admin-header"
import { DashboardHome } from "./dashboard-home"
import { AnalyticsPage } from "./analytics-page"
import { InvestorsPage } from "./investors-page"
import { ProductsPage } from "./products-page"
import { OrdersPage } from "./orders-page"
import { InventoryPage } from "./inventory-page"
import { SettingsPage } from "./settings-page"
import { EasyBuyAdminPage } from "./easybuy-admin-page"

interface AdminDashboardProps {
  adminEmail: string
  onLogout: () => void
}

export function AdminDashboard({ adminEmail, onLogout }: AdminDashboardProps) {
  const [currentPage, setCurrentPage] = useState<AdminPage>("dashboard")

  const renderPage = () => {
    switch (currentPage) {
      case "dashboard":
        return <DashboardHome />
      case "analytics":
        return <AnalyticsPage />
      case "products":
        return <ProductsPage />
      case "orders":
        return <OrdersPage />
      case "inventory":
        return <InventoryPage />
      case "easybuy":
        return <EasyBuyAdminPage />
      case "investors":
        return <InvestorsPage />
      case "settings":
        return <SettingsPage />
      default:
        return <DashboardHome />
    }
  }

  return (
    <SidebarProvider>
      <AdminSidebar currentPage={currentPage} onPageChange={setCurrentPage} onLogout={onLogout} />
      <SidebarInset>
        <AdminHeader currentPage={currentPage} adminEmail={adminEmail} onLogout={onLogout} />
        <main className="flex-1 overflow-auto">{renderPage()}</main>
      </SidebarInset>
    </SidebarProvider>
  )
}
