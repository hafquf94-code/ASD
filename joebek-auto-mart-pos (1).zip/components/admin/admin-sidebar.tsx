"use client"

import { BarChart3, Box, CreditCard, Home, LogOut, Package, Settings, ShoppingCart, Users } from "lucide-react"
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarSeparator,
} from "@/components/ui/sidebar"
import { Car } from "lucide-react"

export type AdminPage = "dashboard" | "products" | "orders" | "inventory" | "analytics" | "easybuy" | "investors" | "settings"

interface AdminSidebarProps {
  currentPage: AdminPage
  onPageChange: (page: AdminPage) => void
  onLogout: () => void
}

const menuItems = [
  { id: "dashboard" as AdminPage, label: "Dashboard", icon: Home },
  { id: "products" as AdminPage, label: "Products", icon: Package },
  { id: "orders" as AdminPage, label: "Orders", icon: ShoppingCart },
  { id: "inventory" as AdminPage, label: "Inventory", icon: Box },
  { id: "analytics" as AdminPage, label: "Analytics", icon: BarChart3 },
  { id: "easybuy" as AdminPage, label: "Easy Buy", icon: CreditCard },
  { id: "investors" as AdminPage, label: "Investors", icon: Users },
  { id: "settings" as AdminPage, label: "Settings", icon: Settings },
]

export function AdminSidebar({ currentPage, onPageChange, onLogout }: AdminSidebarProps) {
  return (
    <Sidebar collapsible="icon">
      <SidebarHeader className="p-4">
        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-blue-600 text-white">
            <Car className="h-5 w-5" />
          </div>
          <div className="flex flex-col group-data-[collapsible=icon]:hidden">
            <span className="font-semibold text-sm">JOEBEK</span>
            <span className="text-xs text-muted-foreground">Admin Panel</span>
          </div>
        </div>
      </SidebarHeader>
      <SidebarSeparator />
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => (
                <SidebarMenuItem key={item.id}>
                  <SidebarMenuButton
                    isActive={currentPage === item.id}
                    onClick={() => onPageChange(item.id)}
                    tooltip={item.label}
                  >
                    <item.icon className="h-4 w-4" />
                    <span>{item.label}</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter>
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton onClick={onLogout} tooltip="Logout">
              <LogOut className="h-4 w-4" />
              <span>Logout</span>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
    </Sidebar>
  )
}
