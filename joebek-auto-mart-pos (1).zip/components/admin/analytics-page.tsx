"use client"

import { useState } from "react"
import {
  ArrowDownRight,
  ArrowUpRight,
  Calendar,
  CreditCard,
  Download,
  Mail,
  MapPin,
  RefreshCw,
  ShoppingCart,
  TrendingUp,
  Users,
  AlertTriangle,
} from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  Pie,
  PieChart,
  XAxis,
  YAxis,
} from "recharts"
import {
  mockAdminStats,
  mockRevenueData,
  mockCategorySales,
  mockTopProducts,
  mockBottomProducts,
  mockTopCustomers,
  mockDebtAging,
  mockNewVsReturning,
  mockCustomersByLocation,
} from "@/lib/admin-mock-data"
import { formatCurrency, formatNumber } from "@/lib/admin-types"

type DatePreset = "7d" | "30d" | "90d" | "12m" | "custom"
type RevenueFilter = "all" | "online" | "pos" | "easybuy"
type Granularity = "daily" | "weekly" | "monthly"

const CATEGORY_COLORS = ["#3b82f6", "#f97316", "#22c55e", "#8b5cf6", "#f59e0b", "#ef4444", "#06b6d4"]

export function AnalyticsPage() {
  const [datePreset, setDatePreset] = useState<DatePreset>("30d")
  const [compareEnabled, setCompareEnabled] = useState(false)
  const [revenueFilter, setRevenueFilter] = useState<RevenueFilter>("all")
  const [granularity, setGranularity] = useState<Granularity>("daily")

  const stats = mockAdminStats

  const filteredRevenueData = mockRevenueData.map((d) => {
    if (revenueFilter === "online") return { ...d, value: d.online }
    if (revenueFilter === "pos") return { ...d, value: d.pos }
    if (revenueFilter === "easybuy") return { ...d, value: d.easyBuy }
    return { ...d, value: d.total }
  })

  return (
    <div className="space-y-6 p-6">
      {/* Header with Date Range */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Analytics</h1>
          <p className="text-muted-foreground">Comprehensive business insights and reports</p>
        </div>
        <div className="flex items-center gap-3 flex-wrap">
          <Select value={datePreset} onValueChange={(v) => setDatePreset(v as DatePreset)}>
            <SelectTrigger className="w-[140px]">
              <Calendar className="h-4 w-4 mr-2" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7d">Last 7 days</SelectItem>
              <SelectItem value="30d">Last 30 days</SelectItem>
              <SelectItem value="90d">Last 90 days</SelectItem>
              <SelectItem value="12m">Last 12 months</SelectItem>
              <SelectItem value="custom">Custom Range</SelectItem>
            </SelectContent>
          </Select>
          <div className="flex items-center gap-2">
            <Switch id="compare" checked={compareEnabled} onCheckedChange={setCompareEnabled} />
            <Label htmlFor="compare" className="text-sm">
              Compare with previous period
            </Label>
          </div>
        </div>
      </div>

      {/* Top Metrics Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Revenue</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-xl font-bold">{formatCurrency(stats.weekRevenue)}</div>
            <div className="flex items-center text-xs">
              <ArrowUpRight className="h-3 w-3 text-green-500" />
              <span className="text-green-500">12.5%</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Orders</CardTitle>
            <ShoppingCart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-xl font-bold">{formatNumber(stats.monthOrders)}</div>
            <div className="flex items-center text-xs">
              <ArrowUpRight className="h-3 w-3 text-green-500" />
              <span className="text-green-500">8.2%</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Avg Order Value</CardTitle>
            <CreditCard className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-xl font-bold">{formatCurrency(stats.averageOrderValue)}</div>
            <div className="flex items-center text-xs">
              <ArrowUpRight className="h-3 w-3 text-green-500" />
              <span className="text-green-500">{stats.averageOrderValueChange}%</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Conversion Rate</CardTitle>
            <RefreshCw className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-xl font-bold">{stats.conversionRate}%</div>
            <div className="flex items-center text-xs">
              <ArrowUpRight className="h-3 w-3 text-green-500" />
              <span className="text-green-500">{stats.conversionRateChange}%</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Returning</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-xl font-bold">{stats.returningCustomers}</div>
            <div className="flex items-center text-xs">
              <ArrowUpRight className="h-3 w-3 text-green-500" />
              <span className="text-green-500">{stats.returningCustomersChange}%</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">New Customers</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-xl font-bold">{stats.newCustomers}</div>
            <div className="flex items-center text-xs">
              <ArrowDownRight className="h-3 w-3 text-red-500" />
              <span className="text-red-500">{Math.abs(stats.newCustomersChange)}%</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Revenue Chart Section */}
      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <CardTitle>Revenue Over Time</CardTitle>
              <CardDescription>
                {compareEnabled ? "With previous period comparison" : "Filtered by selected range"}
              </CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <div className="flex border rounded-lg overflow-hidden">
                {(["all", "online", "pos", "easybuy"] as RevenueFilter[]).map((filter) => (
                  <button
                    key={filter}
                    onClick={() => setRevenueFilter(filter)}
                    className={`px-3 py-1.5 text-sm ${
                      revenueFilter === filter ? "bg-blue-600 text-white" : "bg-background hover:bg-muted"
                    }`}
                  >
                    {filter === "all"
                      ? "Both"
                      : filter === "easybuy"
                        ? "Easy Buy"
                        : filter.charAt(0).toUpperCase() + filter.slice(1)}
                  </button>
                ))}
              </div>
              <Select value={granularity} onValueChange={(v) => setGranularity(v as Granularity)}>
                <SelectTrigger className="w-[100px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="daily">Daily</SelectItem>
                  <SelectItem value="weekly">Weekly</SelectItem>
                  <SelectItem value="monthly">Monthly</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <ChartContainer
            config={{
              value: { label: "Revenue", color: "#3b82f6" },
              comparison: { label: "Previous Period", color: "#94a3b8" },
            }}
            className="h-[350px]"
          >
            <AreaChart data={filteredRevenueData}>
              <defs>
                <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="date" fontSize={12} tickLine={false} />
              <YAxis fontSize={12} tickLine={false} tickFormatter={(v) => `₦${(v / 1000).toFixed(0)}k`} />
              <ChartTooltip content={<ChartTooltipContent />} formatter={(value) => formatCurrency(value as number)} />
              {compareEnabled && (
                <Line
                  type="monotone"
                  dataKey="value"
                  stroke="#94a3b8"
                  strokeWidth={2}
                  strokeDasharray="5 5"
                  dot={false}
                  data={filteredRevenueData.map((d) => ({ ...d, value: d.value * 0.85 }))}
                />
              )}
              <Area
                type="monotone"
                dataKey="value"
                stroke="#3b82f6"
                strokeWidth={2}
                fillOpacity={1}
                fill="url(#colorRevenue)"
              />
            </AreaChart>
          </ChartContainer>
        </CardContent>
      </Card>

      {/* Product Performance */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* Top Selling Products */}
        <Card>
          <CardHeader>
            <CardTitle>Top Selling Products</CardTitle>
            <CardDescription>Best performers by revenue</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12">#</TableHead>
                  <TableHead>Product</TableHead>
                  <TableHead className="text-right">Units</TableHead>
                  <TableHead className="text-right">Revenue</TableHead>
                  <TableHead>Stock</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {mockTopProducts.map((product, index) => (
                  <TableRow key={product.id}>
                    <TableCell className="font-bold text-blue-600">{index + 1}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <img
                          src={product.image || "/placeholder.svg"}
                          alt={product.name}
                          className="h-8 w-8 rounded object-cover"
                        />
                        <span className="font-medium text-sm truncate max-w-[150px]">{product.name}</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-right">{formatNumber(product.unitsSold)}</TableCell>
                    <TableCell className="text-right font-medium">{formatCurrency(product.revenue)}</TableCell>
                    <TableCell>
                      <Badge variant={product.stock < product.threshold ? "destructive" : "secondary"}>
                        {product.stock}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Bottom 5 Products */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              Bottom 5 Products
              <Badge variant="outline" className="text-orange-500 border-orange-500">
                Needs Attention
              </Badge>
            </CardTitle>
            <CardDescription>Low performers that may need marketing</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12">#</TableHead>
                  <TableHead>Product</TableHead>
                  <TableHead className="text-right">Units</TableHead>
                  <TableHead className="text-right">Revenue</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {mockBottomProducts.map((product, index) => (
                  <TableRow key={product.id}>
                    <TableCell className="font-bold text-muted-foreground">{index + 1}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <img
                          src={product.image || "/placeholder.svg"}
                          alt={product.name}
                          className="h-8 w-8 rounded object-cover"
                        />
                        <span className="font-medium text-sm truncate max-w-[150px]">{product.name}</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-right text-muted-foreground">
                      {formatNumber(product.unitsSold)}
                    </TableCell>
                    <TableCell className="text-right">{formatCurrency(product.revenue)}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className="text-orange-500">
                        <AlertTriangle className="h-3 w-3 mr-1" />
                        Low
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

      {/* Category Performance Pie Chart */}
      <Card>
        <CardHeader>
          <CardTitle>Category Performance</CardTitle>
          <CardDescription>Revenue distribution by product category</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid lg:grid-cols-2 gap-6">
            <ChartContainer
              config={Object.fromEntries(
                mockCategorySales.map((c, i) => [
                  c.category.toLowerCase(),
                  { label: c.category, color: CATEGORY_COLORS[i] },
                ]),
              )}
              className="h-[300px]"
            >
              <PieChart>
                <Pie
                  data={mockCategorySales}
                  cx="50%"
                  cy="50%"
                  outerRadius={100}
                  dataKey="revenue"
                  nameKey="category"
                  label={({ category, percentage }) => `${category} (${percentage}%)`}
                >
                  {mockCategorySales.map((_, index) => (
                    <Cell key={`cell-${index}`} fill={CATEGORY_COLORS[index]} />
                  ))}
                </Pie>
                <ChartTooltip
                  content={<ChartTooltipContent />}
                  formatter={(value) => formatCurrency(value as number)}
                />
              </PieChart>
            </ChartContainer>
            <div className="space-y-3">
              {mockCategorySales.map((cat, index) => (
                <div key={cat.category} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: CATEGORY_COLORS[index] }} />
                    <span className="text-sm">{cat.category}</span>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="font-medium">{formatCurrency(cat.revenue)}</span>
                    <Badge variant="secondary">{cat.percentage}%</Badge>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Customer Insights */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* New vs Returning */}
        <Card>
          <CardHeader>
            <CardTitle>New vs Returning Customers</CardTitle>
            <CardDescription>Monthly customer acquisition trends</CardDescription>
          </CardHeader>
          <CardContent>
            <ChartContainer
              config={{
                new: { label: "New Customers", color: "#3b82f6" },
                returning: { label: "Returning Customers", color: "#22c55e" },
              }}
              className="h-[280px]"
            >
              <BarChart data={mockNewVsReturning}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="month" fontSize={12} tickLine={false} />
                <YAxis fontSize={12} tickLine={false} />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Legend />
                <Bar dataKey="new" stackId="a" fill="#3b82f6" radius={[0, 0, 0, 0]} />
                <Bar dataKey="returning" stackId="a" fill="#22c55e" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ChartContainer>
          </CardContent>
        </Card>

        {/* Top Customers by Lifetime Value */}
        <Card>
          <CardHeader>
            <CardTitle>Customer Lifetime Value</CardTitle>
            <CardDescription>Top 5 customers by total spend</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Customer</TableHead>
                  <TableHead className="text-right">Orders</TableHead>
                  <TableHead className="text-right">Total Spent</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {mockTopCustomers.map((customer) => (
                  <TableRow key={customer.id}>
                    <TableCell>
                      <div>
                        <div className="font-medium">{customer.name}</div>
                        <div className="text-xs text-muted-foreground">{customer.email}</div>
                      </div>
                    </TableCell>
                    <TableCell className="text-right">{customer.orderCount}</TableCell>
                    <TableCell className="text-right font-medium">{formatCurrency(customer.totalSpent)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

      {/* Geographic Distribution */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MapPin className="h-5 w-5" />
            Sales by Location
          </CardTitle>
          <CardDescription>Geographic distribution of customers and revenue</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Location</TableHead>
                <TableHead className="text-right">Customers</TableHead>
                <TableHead className="text-right">Revenue</TableHead>
                <TableHead>Distribution</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {mockCustomersByLocation.map((loc) => {
                const totalRevenue = mockCustomersByLocation.reduce((s, l) => s + l.revenue, 0)
                const percentage = ((loc.revenue / totalRevenue) * 100).toFixed(1)
                return (
                  <TableRow key={loc.location}>
                    <TableCell className="font-medium">{loc.location}</TableCell>
                    <TableCell className="text-right">{loc.customers}</TableCell>
                    <TableCell className="text-right">{formatCurrency(loc.revenue)}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <div className="w-24 h-2 bg-muted rounded-full overflow-hidden">
                          <div className="h-full bg-blue-600 rounded-full" style={{ width: `${percentage}%` }} />
                        </div>
                        <span className="text-sm text-muted-foreground">{percentage}%</span>
                      </div>
                    </TableCell>
                  </TableRow>
                )
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Easy Buy Analytics */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CreditCard className="h-5 w-5" />
            Easy Buy Analytics
          </CardTitle>
          <CardDescription>Credit sales performance and debt overview</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">Total Outstanding Debt</p>
              <p className="text-3xl font-bold">{formatCurrency(stats.totalOutstandingDebt)}</p>
            </div>
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">Collection Rate This Month</p>
              <div className="flex items-center gap-2">
                <p className="text-3xl font-bold">{stats.collectionRate}%</p>
                <Badge className="bg-green-500 text-white">
                  <ArrowUpRight className="h-3 w-3 mr-1" />
                  {stats.collectionRateChange}%
                </Badge>
              </div>
            </div>
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">At-Risk Customers</p>
              <div className="flex items-center gap-2">
                <p className="text-3xl font-bold">{stats.atRiskCustomers}</p>
                <Badge variant="destructive">{stats.atRiskCustomers}</Badge>
              </div>
            </div>
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">Debt Aging Breakdown</p>
              <div className="space-y-1.5">
                {mockDebtAging.map((aging) => {
                  const totalDebt = mockDebtAging.reduce((s, a) => s + a.amount, 0)
                  const percentage = ((aging.amount / totalDebt) * 100).toFixed(0)
                  const color =
                    aging.range === "0-30 days"
                      ? "bg-green-500"
                      : aging.range === "31-60 days"
                        ? "bg-yellow-500"
                        : aging.range === "61-90 days"
                          ? "bg-orange-500"
                          : "bg-red-500"
                  return (
                    <div key={aging.range} className="flex items-center gap-2">
                      <div className={`w-2 h-2 rounded-full ${color}`} />
                      <span className="text-xs flex-1">{aging.range}</span>
                      <span className="text-xs font-medium">{percentage}%</span>
                    </div>
                  )
                })}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Export Section */}
      <Card>
        <CardHeader>
          <CardTitle>Export Reports</CardTitle>
          <CardDescription>Download or schedule automated reports</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-3">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button className="bg-blue-600 hover:bg-blue-700 text-white">
                  <Download className="h-4 w-4 mr-2" />
                  Export Report
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem>Download as PDF</DropdownMenuItem>
                <DropdownMenuItem>Download as Excel</DropdownMenuItem>
                <DropdownMenuItem>Download as CSV</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline">
                  <Mail className="h-4 w-4 mr-2" />
                  Schedule Report
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem>Daily Email</DropdownMenuItem>
                <DropdownMenuItem>Weekly Email</DropdownMenuItem>
                <DropdownMenuItem>Monthly Email</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
