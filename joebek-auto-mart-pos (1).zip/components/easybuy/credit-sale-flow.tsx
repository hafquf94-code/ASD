"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { X, Search, AlertTriangle, Check, Printer, MessageSquare } from "lucide-react"
import type { EasyBuyCustomer } from "@/lib/easybuy-types"
import { MOCK_EASYBUY_CUSTOMERS } from "@/lib/easybuy-mock-data"
import { getDebtLevel, getDebtLevelColor } from "@/lib/easybuy-types"

interface CreditSaleFlowProps {
  cartTotal: number
  onClose: () => void
  onComplete: () => void
}

type FlowStep = "search" | "confirm" | "insufficient" | "complete"

export function CreditSaleFlow({ cartTotal, onClose, onComplete }: CreditSaleFlowProps) {
  const [step, setStep] = useState<FlowStep>("search")
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCustomer, setSelectedCustomer] = useState<EasyBuyCustomer | null>(null)

  const filteredCustomers = MOCK_EASYBUY_CUSTOMERS.filter((c) => {
    if (!searchQuery) return false
    const query = searchQuery.toLowerCase()
    return (
      c.fullName.toLowerCase().includes(query) || c.phone.includes(query) || c.easyBuyId.toLowerCase().includes(query)
    )
  })

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-NG", {
      style: "currency",
      currency: "NGN",
      minimumFractionDigits: 0,
    }).format(amount)
  }

  const handleSelectCustomer = (customer: EasyBuyCustomer) => {
    setSelectedCustomer(customer)
    const availableCredit = customer.creditLimit - customer.currentDebt
    if (availableCredit >= cartTotal) {
      setStep("confirm")
    } else {
      setStep("insufficient")
    }
  }

  const handleApprove = () => {
    setStep("complete")
    setTimeout(() => {
      onComplete()
    }, 3000)
  }

  // Search Step
  if (step === "search") {
    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
        <Card className="w-full max-w-lg max-h-[80vh] flex flex-col">
          <div className="flex items-center justify-between p-4 border-b border-border">
            <div>
              <h2 className="text-lg font-bold text-foreground">Easy Buy Credit Sale</h2>
              <p className="text-sm text-muted-foreground">Cart Total: {formatCurrency(cartTotal)}</p>
            </div>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="w-5 h-5" />
            </Button>
          </div>

          <div className="p-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input
                type="text"
                placeholder="Search customer by name, phone, or ID"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 h-11"
                autoFocus
              />
            </div>
          </div>

          <div className="flex-1 overflow-auto p-4 pt-0">
            {filteredCustomers.length > 0 ? (
              <div className="space-y-2">
                {filteredCustomers.map((customer) => {
                  const availableCredit = Math.max(0, customer.creditLimit - customer.currentDebt)
                  const debtLevel = getDebtLevel(customer.currentDebt, customer.creditLimit)

                  return (
                    <button
                      key={customer.id}
                      onClick={() => handleSelectCustomer(customer)}
                      className="w-full p-3 rounded-lg border border-border hover:bg-muted/50 transition-colors text-left"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-full overflow-hidden bg-muted flex-shrink-0">
                          <img
                            src={customer.photo || "/placeholder.svg?height=48&width=48&query=person avatar"}
                            alt={customer.fullName}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-foreground">{customer.fullName}</p>
                          <p className="text-xs text-muted-foreground">{customer.easyBuyId}</p>
                        </div>
                        <div className="text-right">
                          <p className={`text-sm font-medium ${getDebtLevelColor(debtLevel).split(" ")[0]}`}>
                            Debt: {formatCurrency(customer.currentDebt)}
                          </p>
                          <p className="text-xs text-green-600">Available: {formatCurrency(availableCredit)}</p>
                        </div>
                      </div>
                    </button>
                  )
                })}
              </div>
            ) : searchQuery ? (
              <div className="text-center py-8 text-muted-foreground">No customers found matching "{searchQuery}"</div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">Start typing to search for a customer</div>
            )}
          </div>
        </Card>
      </div>
    )
  }

  // Confirm Step
  if (step === "confirm" && selectedCustomer) {
    const newDebt = selectedCustomer.currentDebt + cartTotal
    const availableAfter = selectedCustomer.creditLimit - newDebt

    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
        <Card className="w-full max-w-md p-6">
          <h2 className="text-lg font-bold text-foreground mb-4">Confirm Credit Sale</h2>

          <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg mb-4">
            <div className="w-12 h-12 rounded-full overflow-hidden bg-muted">
              <img
                src={selectedCustomer.photo || "/placeholder.svg?height=48&width=48&query=person avatar"}
                alt={selectedCustomer.fullName}
                className="w-full h-full object-cover"
              />
            </div>
            <div>
              <p className="font-medium">{selectedCustomer.fullName}</p>
              <p className="text-sm text-muted-foreground">{selectedCustomer.easyBuyId}</p>
            </div>
          </div>

          <div className="space-y-3 mb-6">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Cart Total:</span>
              <span className="font-bold text-lg">{formatCurrency(cartTotal)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Current Debt:</span>
              <span className="text-red-600">{formatCurrency(selectedCustomer.currentDebt)}</span>
            </div>
            <div className="flex justify-between border-t pt-2">
              <span className="text-muted-foreground">New Debt Will Be:</span>
              <span className="font-bold text-red-600">{formatCurrency(newDebt)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Available Credit Remaining:</span>
              <span className="text-green-600">{formatCurrency(availableAfter)}</span>
            </div>
          </div>

          <div className="flex gap-3">
            <Button variant="outline" onClick={() => setStep("search")} className="flex-1 touch-target">
              Cancel
            </Button>
            <Button onClick={handleApprove} className="flex-1 bg-green-600 hover:bg-green-700 text-white touch-target">
              Approve Credit Sale
            </Button>
          </div>
        </Card>
      </div>
    )
  }

  // Insufficient Credit Step
  if (step === "insufficient" && selectedCustomer) {
    const availableCredit = selectedCustomer.creditLimit - selectedCustomer.currentDebt
    const shortfall = cartTotal - availableCredit

    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
        <Card className="w-full max-w-md p-6">
          <div className="text-center mb-4">
            <div className="w-16 h-16 rounded-full bg-red-100 flex items-center justify-center mx-auto mb-4">
              <AlertTriangle className="w-8 h-8 text-red-600" />
            </div>
            <h2 className="text-lg font-bold text-red-600">Insufficient Credit</h2>
          </div>

          <div className="p-4 bg-red-50 rounded-lg mb-4 text-sm">
            <p className="text-red-800">
              <strong>{selectedCustomer.fullName}</strong> does not have enough available credit for this purchase.
            </p>
          </div>

          <div className="space-y-2 mb-6 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Cart Total:</span>
              <span className="font-medium">{formatCurrency(cartTotal)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Available Credit:</span>
              <span className="text-green-600">{formatCurrency(availableCredit)}</span>
            </div>
            <div className="flex justify-between text-red-600">
              <span>Shortfall:</span>
              <span className="font-bold">{formatCurrency(shortfall)}</span>
            </div>
          </div>

          <div className="flex flex-col gap-2">
            <Button variant="outline" disabled className="touch-target bg-transparent">
              Increase Limit (Admin Only)
            </Button>
            <Button variant="outline" onClick={() => setStep("search")} className="touch-target">
              Select Different Customer
            </Button>
            <Button variant="outline" onClick={onClose} className="touch-target bg-transparent">
              Cancel
            </Button>
          </div>
        </Card>
      </div>
    )
  }

  // Complete Step
  if (step === "complete" && selectedCustomer) {
    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
        <Card className="w-full max-w-md p-8 text-center">
          <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4">
            <Check className="w-8 h-8 text-green-600" />
          </div>
          <h2 className="text-xl font-bold text-foreground mb-2">Credit Sale Complete</h2>
          <p className="text-muted-foreground mb-6">
            {formatCurrency(cartTotal)} charged to {selectedCustomer.fullName}'s Easy Buy account.
          </p>

          <div className="flex gap-3">
            <Button variant="outline" className="flex-1 touch-target bg-transparent">
              <Printer className="w-4 h-4 mr-2" />
              Print Receipt
            </Button>
            <Button variant="outline" className="flex-1 touch-target bg-transparent">
              <MessageSquare className="w-4 h-4 mr-2" />
              Send SMS
            </Button>
          </div>

          <p className="text-xs text-muted-foreground mt-4">Auto-closing in 3 seconds...</p>
        </Card>
      </div>
    )
  }

  return null
}
