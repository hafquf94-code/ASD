"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import {
  ArrowLeft,
  Phone,
  Mail,
  MapPin,
  Calendar,
  CreditCard,
  Shield,
  User,
  Eye,
  Pencil,
  PauseCircle,
  PlayCircle,
} from "lucide-react"
import type { EasyBuyCustomer, CreditPayment } from "@/lib/easybuy-types"
import { getDebtLevel, getDebtLevelColor } from "@/lib/easybuy-types"
import { MOCK_CREDIT_PURCHASES, MOCK_CREDIT_PAYMENTS } from "@/lib/easybuy-mock-data"
import { RecordPaymentModal } from "./record-payment-modal"
import { PurchaseHistoryTab } from "./purchase-history-tab"
import { PaymentHistoryTab } from "./payment-history-tab"

interface CustomerDetailViewProps {
  customer: EasyBuyCustomer
  staffName: string
  onBack: () => void
  onUpdateCustomer: (customer: EasyBuyCustomer) => void
}

type DetailTab = "purchases" | "payments"

export function CustomerDetailView({ customer, staffName, onBack, onUpdateCustomer }: CustomerDetailViewProps) {
  const [activeTab, setActiveTab] = useState<DetailTab>("purchases")
  const [showPaymentModal, setShowPaymentModal] = useState(false)
  const [payments, setPayments] = useState<CreditPayment[]>(
    MOCK_CREDIT_PAYMENTS.filter((p) => p.customerId === customer.id),
  )

  const purchases = MOCK_CREDIT_PURCHASES.filter((p) => p.customerId === customer.id)

  const debtLevel = getDebtLevel(customer.currentDebt, customer.creditLimit)
  const debtLevelColorClass = getDebtLevelColor(debtLevel)
  const availableCredit = Math.max(0, customer.creditLimit - customer.currentDebt)
  const debtPercentage = Math.min(100, (customer.currentDebt / customer.creditLimit) * 100)

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-NG", {
      style: "currency",
      currency: "NGN",
      minimumFractionDigits: 0,
    }).format(amount)
  }

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat("en-NG", {
      day: "numeric",
      month: "short",
      year: "numeric",
    }).format(date)
  }

  const handleToggleStatus = () => {
    const newStatus = customer.status === "active" ? "suspended" : "active"
    onUpdateCustomer({ ...customer, status: newStatus })
  }

  const handlePaymentRecorded = (amount: number, method: string, receiptNumber?: string) => {
    const newPayment: CreditPayment = {
      id: `pay-${Date.now()}`,
      customerId: customer.id,
      amount,
      paymentMethod: method as CreditPayment["paymentMethod"],
      receiptNumber,
      date: new Date(),
      recordedBy: staffName,
      balanceAfter: customer.currentDebt - amount,
    }
    setPayments((prev) => [newPayment, ...prev])
    onUpdateCustomer({
      ...customer,
      currentDebt: customer.currentDebt - amount,
      lastPaymentDate: new Date(),
    })
    setShowPaymentModal(false)
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border px-4 py-3">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="sm" onClick={onBack} className="text-muted-foreground hover:text-foreground">
            <ArrowLeft className="w-4 h-4 mr-1" />
            Back to Customers
          </Button>
          <div className="h-6 w-px bg-border" />
          <div>
            <h1 className="font-bold text-foreground text-lg">Customer Details</h1>
            <p className="text-xs text-muted-foreground">{customer.easyBuyId}</p>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="p-4 flex flex-col lg:flex-row gap-4">
        {/* Left Side - Customer Info */}
        <div className="lg:w-[45%] flex flex-col gap-4">
          {/* Customer Card */}
          <Card className="p-6">
            <div className="flex items-start gap-4">
              <div className="w-24 h-24 rounded-xl overflow-hidden bg-muted flex-shrink-0">
                <img
                  src={customer.photo || "/placeholder.svg?height=96&width=96&query=person avatar"}
                  alt={customer.fullName}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <h2 className="text-xl font-bold text-foreground">{customer.fullName}</h2>
                  <span
                    className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      customer.status === "active" ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
                    }`}
                  >
                    {customer.status === "active" ? "Active" : "Suspended"}
                  </span>
                </div>
                <p className="text-sm text-muted-foreground mb-3">{customer.easyBuyId}</p>

                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Phone className="w-4 h-4" />
                    <span>{customer.phone}</span>
                  </div>
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Mail className="w-4 h-4" />
                    <span>{customer.email}</span>
                  </div>
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <MapPin className="w-4 h-4" />
                    <span>{customer.address}</span>
                  </div>
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Calendar className="w-4 h-4" />
                    <span>Registered: {formatDate(customer.registrationDate)}</span>
                  </div>
                </div>
              </div>
            </div>
          </Card>

          {/* ID Information */}
          <Card className="p-4">
            <div className="flex items-center gap-2 mb-3">
              <CreditCard className="w-5 h-5 text-primary" />
              <h3 className="font-semibold text-foreground">ID Information</h3>
            </div>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-muted-foreground">Card Type</p>
                <p className="font-medium capitalize">{customer.idCard.type.replace(/_/g, " ")}</p>
              </div>
              <div>
                <p className="text-muted-foreground">ID Number</p>
                <p className="font-medium">{customer.idCard.number}</p>
              </div>
            </div>
            <Button variant="outline" size="sm" className="mt-3 touch-target bg-transparent">
              <Eye className="w-4 h-4 mr-2" />
              View Uploaded ID
            </Button>
          </Card>

          {/* Guarantor Information */}
          <Card className="p-4">
            <div className="flex items-center gap-2 mb-3">
              <Shield className="w-5 h-5 text-primary" />
              <h3 className="font-semibold text-foreground">Guarantor Information</h3>
              {customer.guarantor.verified && (
                <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                  Verified
                </span>
              )}
            </div>
            <div className="space-y-2 text-sm">
              <div className="flex items-center gap-2">
                <User className="w-4 h-4 text-muted-foreground" />
                <span className="font-medium">{customer.guarantor.name}</span>
                <span className="text-muted-foreground">({customer.guarantor.relationship})</span>
              </div>
              <div className="flex items-center gap-2 text-muted-foreground">
                <Phone className="w-4 h-4" />
                <span>{customer.guarantor.phone}</span>
              </div>
              <div className="flex items-center gap-2 text-muted-foreground">
                <MapPin className="w-4 h-4" />
                <span>{customer.guarantor.address}</span>
              </div>
            </div>
          </Card>
        </div>

        {/* Right Side - Credit Info & Actions */}
        <div className="lg:w-[55%] flex flex-col gap-4">
          {/* Credit Summary Card */}
          <Card className="p-6">
            <h3 className="font-semibold text-foreground mb-4">Credit Summary</h3>
            <div className="grid grid-cols-3 gap-4 mb-4">
              <div className="text-center p-4 bg-muted/30 rounded-lg">
                <p className="text-sm text-muted-foreground mb-1">Credit Limit</p>
                <p className="text-2xl font-bold text-foreground">{formatCurrency(customer.creditLimit)}</p>
              </div>
              <div className="text-center p-4 bg-red-50 rounded-lg">
                <p className="text-sm text-muted-foreground mb-1">Current Debt</p>
                <p className={`text-2xl font-bold ${debtLevelColorClass.split(" ")[0]}`}>
                  {formatCurrency(customer.currentDebt)}
                </p>
              </div>
              <div className="text-center p-4 bg-green-50 rounded-lg">
                <p className="text-sm text-muted-foreground mb-1">Available Credit</p>
                <p className="text-2xl font-bold text-green-600">{formatCurrency(availableCredit)}</p>
              </div>
            </div>

            {/* Debt Percentage Bar */}
            <div className="mb-4">
              <div className="flex justify-between text-sm mb-1">
                <span className="text-muted-foreground">Debt Usage</span>
                <span className="font-medium">{debtPercentage.toFixed(0)}%</span>
              </div>
              <div className="h-3 bg-muted rounded-full overflow-hidden">
                <div
                  className={`h-full transition-all ${
                    debtPercentage > 100
                      ? "bg-red-800"
                      : debtPercentage > 80
                        ? "bg-red-500"
                        : debtPercentage >= 50
                          ? "bg-yellow-500"
                          : "bg-green-500"
                  }`}
                  style={{ width: `${Math.min(100, debtPercentage)}%` }}
                />
              </div>
            </div>

            {/* Action Buttons */}
            <div className="grid grid-cols-2 gap-3">
              <Button
                onClick={() => setShowPaymentModal(true)}
                className="bg-green-600 hover:bg-green-700 text-white touch-target"
              >
                Record Payment
              </Button>
              <Button className="bg-primary hover:bg-primary/90 touch-target">New Credit Sale</Button>
              <Button variant="outline" className="touch-target bg-transparent">
                <Pencil className="w-4 h-4 mr-2" />
                Edit Customer
              </Button>
              <Button
                variant="outline"
                onClick={handleToggleStatus}
                className={`touch-target bg-transparent ${
                  customer.status === "active" ? "text-red-600 hover:bg-red-50" : "text-green-600 hover:bg-green-50"
                }`}
              >
                {customer.status === "active" ? (
                  <>
                    <PauseCircle className="w-4 h-4 mr-2" />
                    Suspend
                  </>
                ) : (
                  <>
                    <PlayCircle className="w-4 h-4 mr-2" />
                    Activate
                  </>
                )}
              </Button>
            </div>
          </Card>

          {/* History Tabs */}
          <Card className="flex-1 flex flex-col overflow-hidden">
            <div className="flex border-b border-border">
              <button
                onClick={() => setActiveTab("purchases")}
                className={`flex-1 px-4 py-3 text-sm font-medium transition-colors touch-target ${
                  activeTab === "purchases"
                    ? "text-primary border-b-2 border-primary"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                Purchase History
              </button>
              <button
                onClick={() => setActiveTab("payments")}
                className={`flex-1 px-4 py-3 text-sm font-medium transition-colors touch-target ${
                  activeTab === "payments"
                    ? "text-primary border-b-2 border-primary"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                Payment History
              </button>
            </div>
            <div className="flex-1 overflow-auto">
              {activeTab === "purchases" ? (
                <PurchaseHistoryTab purchases={purchases} />
              ) : (
                <PaymentHistoryTab payments={payments} />
              )}
            </div>
          </Card>
        </div>
      </div>

      {/* Record Payment Modal */}
      {showPaymentModal && (
        <RecordPaymentModal
          currentDebt={customer.currentDebt}
          onClose={() => setShowPaymentModal(false)}
          onRecordPayment={handlePaymentRecorded}
        />
      )}
    </div>
  )
}
