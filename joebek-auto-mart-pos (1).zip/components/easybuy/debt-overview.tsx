"use client"

import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { AlertTriangle, TrendingUp, Users, DollarSign, Clock, Phone } from "lucide-react"
import { MOCK_DEBT_OVERVIEW_STATS, MOCK_DEBT_AGING, MOCK_EASYBUY_CUSTOMERS } from "@/lib/easybuy-mock-data"

export function EasyBuyDebtOverview() {
  const stats = MOCK_DEBT_OVERVIEW_STATS
  const aging = MOCK_DEBT_AGING

  // Get top 5 debtors
  const topDebtors = [...MOCK_EASYBUY_CUSTOMERS].sort((a, b) => b.currentDebt - a.currentDebt).slice(0, 5)

  // Get overdue customers
  const overdueCustomers = MOCK_EASYBUY_CUSTOMERS.filter((c) => c.currentDebt > c.creditLimit)

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-NG", {
      style: "currency",
      currency: "NGN",
      minimumFractionDigits: 0,
    }).format(amount)
  }

  const maxAgingValue = Math.max(aging.days0to30, aging.days31to60, aging.days61to90, aging.days90plus)

  return (
    <div className="p-4 space-y-4">
      {/* Stat Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        <Card className="p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Total Outstanding</p>
              <p className="text-xl font-bold text-foreground">{formatCurrency(stats.totalOutstandingDebt)}</p>
            </div>
          </div>
        </Card>

        <Card className="p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-purple-100 flex items-center justify-center">
              <Users className="w-5 h-5 text-purple-600" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Customers with Debt</p>
              <p className="text-xl font-bold text-foreground">{stats.customersWithDebt}</p>
            </div>
          </div>
        </Card>

        <Card className="p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-orange-100 flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-orange-600" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Avg Debt/Customer</p>
              <p className="text-xl font-bold text-foreground">{formatCurrency(stats.averageDebtPerCustomer)}</p>
            </div>
          </div>
        </Card>

        <Card className="p-4 bg-red-50 border-red-200">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-red-100 flex items-center justify-center">
              <AlertTriangle className="w-5 h-5 text-red-600" />
            </div>
            <div>
              <p className="text-xs text-red-600">Overdue Payments</p>
              <p className="text-xl font-bold text-red-600">{formatCurrency(stats.overduePayments)}</p>
            </div>
          </div>
        </Card>

        <Card className="p-4 bg-green-50 border-green-200">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-green-100 flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-green-600" />
            </div>
            <div>
              <p className="text-xs text-green-600">Collections This Month</p>
              <p className="text-xl font-bold text-green-600">{formatCurrency(stats.collectionsThisMonth)}</p>
            </div>
          </div>
        </Card>
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        {/* Debt Aging Chart */}
        <Card className="p-4">
          <h3 className="font-semibold text-foreground mb-4">Debt Aging</h3>
          <div className="space-y-3">
            {[
              { label: "0-30 Days", value: aging.days0to30, color: "bg-green-500" },
              { label: "31-60 Days", value: aging.days31to60, color: "bg-yellow-500" },
              { label: "61-90 Days", value: aging.days61to90, color: "bg-orange-500" },
              { label: "90+ Days", value: aging.days90plus, color: "bg-red-500" },
            ].map((item) => (
              <div key={item.label}>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-muted-foreground">{item.label}</span>
                  <span className="font-medium">{formatCurrency(item.value)}</span>
                </div>
                <div className="h-6 bg-muted rounded overflow-hidden">
                  <div
                    className={`h-full ${item.color} transition-all`}
                    style={{ width: `${(item.value / maxAgingValue) * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Top Debtors */}
        <Card className="p-4">
          <h3 className="font-semibold text-foreground mb-4">Top Debtors</h3>
          <div className="space-y-3">
            {topDebtors.map((customer, index) => (
              <div key={customer.id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-muted/50">
                <span className="w-6 h-6 rounded-full bg-muted flex items-center justify-center text-xs font-medium">
                  {index + 1}
                </span>
                <div className="w-8 h-8 rounded-full overflow-hidden bg-muted flex-shrink-0">
                  <img
                    src={customer.photo || "/placeholder.svg?height=32&width=32&query=person avatar"}
                    alt={customer.fullName}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm truncate">{customer.fullName}</p>
                  <p className="text-xs text-muted-foreground">{customer.phone}</p>
                </div>
                <span className="font-semibold text-red-600">{formatCurrency(customer.currentDebt)}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Overdue Alerts */}
      {overdueCustomers.length > 0 && (
        <Card className="p-4 border-red-200 bg-red-50/50">
          <div className="flex items-center gap-2 mb-4">
            <Clock className="w-5 h-5 text-red-600" />
            <h3 className="font-semibold text-red-800">Overdue Alerts</h3>
            <span className="px-2 py-0.5 rounded-full bg-red-100 text-red-800 text-xs font-medium">
              {overdueCustomers.length} customers
            </span>
          </div>
          <div className="space-y-2">
            {overdueCustomers.map((customer) => (
              <div
                key={customer.id}
                className="flex items-center justify-between p-3 bg-white rounded-lg border border-red-200"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full overflow-hidden bg-muted">
                    <img
                      src={customer.photo || "/placeholder.svg?height=40&width=40&query=person avatar"}
                      alt={customer.fullName}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <p className="font-medium text-foreground">{customer.fullName}</p>
                    <p className="text-sm text-red-600">
                      Overdue: {formatCurrency(customer.currentDebt - customer.creditLimit)}
                    </p>
                  </div>
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  className="text-red-600 border-red-300 hover:bg-red-50 touch-target bg-transparent"
                >
                  <Phone className="w-4 h-4 mr-1" />
                  Follow Up
                </Button>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  )
}
