"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { X, Check, Printer } from "lucide-react"
import type { EasyBuyPaymentMethod } from "@/lib/easybuy-types"

interface RecordPaymentModalProps {
  currentDebt: number
  onClose: () => void
  onRecordPayment: (amount: number, method: string, receiptNumber?: string) => void
}

export function RecordPaymentModal({ currentDebt, onClose, onRecordPayment }: RecordPaymentModalProps) {
  const [amount, setAmount] = useState<number>(0)
  const [paymentMethod, setPaymentMethod] = useState<EasyBuyPaymentMethod>("cash")
  const [receiptNumber, setReceiptNumber] = useState("")
  const [paymentDate, setPaymentDate] = useState(new Date().toISOString().split("T")[0])
  const [isRecorded, setIsRecorded] = useState(false)

  const paymentMethods: { value: EasyBuyPaymentMethod; label: string }[] = [
    { value: "cash", label: "Cash" },
    { value: "pos_terminal", label: "POS Terminal" },
    { value: "bank_transfer", label: "Bank Transfer" },
  ]

  const newDebt = Math.max(0, currentDebt - amount)

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("en-NG", {
      style: "currency",
      currency: "NGN",
      minimumFractionDigits: 0,
    }).format(value)
  }

  const handleSubmit = () => {
    if (amount > 0) {
      setIsRecorded(true)
      setTimeout(() => {
        onRecordPayment(amount, paymentMethod, receiptNumber || undefined)
      }, 2000)
    }
  }

  if (isRecorded) {
    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
        <Card className="w-full max-w-md p-8 text-center">
          <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4">
            <Check className="w-8 h-8 text-green-600" />
          </div>
          <h2 className="text-xl font-bold text-foreground mb-2">Payment Recorded</h2>
          <p className="text-muted-foreground mb-4">{formatCurrency(amount)} has been recorded successfully.</p>
          <p className="text-sm text-muted-foreground mb-6">New balance: {formatCurrency(newDebt)}</p>
          <Button variant="outline" className="w-full touch-target bg-transparent">
            <Printer className="w-4 h-4 mr-2" />
            Print Payment Receipt
          </Button>
        </Card>
      </div>
    )
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-md">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-border">
          <h2 className="text-lg font-bold text-foreground">Record Payment</h2>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="w-5 h-5" />
          </Button>
        </div>

        {/* Content */}
        <div className="p-4 space-y-4">
          {/* Current Debt Display */}
          <div className="text-center p-4 bg-red-50 rounded-lg">
            <p className="text-sm text-muted-foreground mb-1">Current Debt</p>
            <p className="text-3xl font-bold text-red-600">{formatCurrency(currentDebt)}</p>
          </div>

          {/* Amount Input */}
          <div>
            <Label htmlFor="amount">Amount Paying *</Label>
            <div className="relative mt-1">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-lg font-medium text-muted-foreground">
                ₦
              </span>
              <Input
                id="amount"
                type="number"
                value={amount || ""}
                onChange={(e) => setAmount(Number.parseInt(e.target.value) || 0)}
                className="pl-8 text-xl h-14 font-semibold"
                placeholder="0"
              />
            </div>
          </div>

          {/* Payment Method */}
          <div>
            <Label htmlFor="method">Payment Method</Label>
            <select
              id="method"
              value={paymentMethod}
              onChange={(e) => setPaymentMethod(e.target.value as EasyBuyPaymentMethod)}
              className="w-full mt-1 h-10 px-3 rounded-md border border-input bg-background text-foreground"
            >
              {paymentMethods.map((method) => (
                <option key={method.value} value={method.value}>
                  {method.label}
                </option>
              ))}
            </select>
          </div>

          {/* Receipt Number (for bank transfers) */}
          {paymentMethod === "bank_transfer" && (
            <div>
              <Label htmlFor="receipt">Receipt/Reference Number</Label>
              <Input
                id="receipt"
                value={receiptNumber}
                onChange={(e) => setReceiptNumber(e.target.value)}
                placeholder="Enter transfer reference"
                className="mt-1"
              />
            </div>
          )}

          {/* Date */}
          <div>
            <Label htmlFor="date">Payment Date</Label>
            <Input
              id="date"
              type="date"
              value={paymentDate}
              onChange={(e) => setPaymentDate(e.target.value)}
              className="mt-1"
            />
          </div>

          {/* New Debt Preview */}
          <div className="p-3 bg-muted/50 rounded-lg">
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">New debt will be:</span>
              <span className="text-lg font-bold text-foreground">{formatCurrency(newDebt)}</span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex gap-3 p-4 border-t border-border">
          <Button variant="outline" onClick={onClose} className="flex-1 touch-target bg-transparent">
            Cancel
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={amount <= 0}
            className="flex-1 bg-green-600 hover:bg-green-700 text-white touch-target"
          >
            Record Payment
          </Button>
        </div>
      </Card>
    </div>
  )
}
