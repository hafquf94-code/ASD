import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ProductCard } from "./product-card"
import { getFeaturedProducts } from "@/lib/ecommerce-mock-data"
import { ArrowRight } from "lucide-react"

export function FeaturedProducts() {
  const featuredProducts = getFeaturedProducts()

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-12">
          <div>
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-2">
              Featured Products
            </h2>
            <p className="text-lg text-gray-600">
              Top picks from our collection
            </p>
          </div>
          <Link href="/shop" className="hidden sm:block">
            <Button variant="outline" className="border-blue-600 text-blue-600 hover:bg-blue-50">
              View All
              <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {featuredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>

        <div className="mt-8 text-center sm:hidden">
          <Link href="/shop">
            <Button variant="outline" className="w-full border-blue-600 text-blue-600 hover:bg-blue-50">
              View All Products
              <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  )
}
