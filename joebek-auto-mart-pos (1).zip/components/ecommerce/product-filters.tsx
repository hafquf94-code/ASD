"use client"

import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { CATEGORIES } from "@/lib/ecommerce-mock-data"

const brands = ["Bosch", "Toyota", "Honda", "Mobil", "Shell", "Brembo", "NGK", "Denso", "Gates", "Mann"]

export function ProductFilters() {
  return (
    <div className="space-y-6">
      {/* Categories */}
      <div className="pb-6 border-b border-gray-200">
        <h3 className="font-semibold text-gray-900 mb-4">Categories</h3>
        <div className="space-y-3">
          {CATEGORIES.map((category) => (
            <div key={category.id} className="flex items-center gap-2">
              <Checkbox id={`cat-${category.id}`} />
              <Label
                htmlFor={`cat-${category.id}`}
                className="text-sm text-gray-700 cursor-pointer hover:text-blue-600 transition-colors"
              >
                {category.name}
              </Label>
            </div>
          ))}
        </div>
      </div>

      {/* Brands */}
      <div className="pb-6 border-b border-gray-200">
        <h3 className="font-semibold text-gray-900 mb-4">Brands</h3>
        <div className="space-y-3 max-h-64 overflow-y-auto">
          {brands.map((brand) => (
            <div key={brand} className="flex items-center gap-2">
              <Checkbox id={`brand-${brand}`} />
              <Label
                htmlFor={`brand-${brand}`}
                className="text-sm text-gray-700 cursor-pointer hover:text-blue-600 transition-colors"
              >
                {brand}
              </Label>
            </div>
          ))}
        </div>
      </div>

      {/* Price Range */}
      <div className="pb-6 border-b border-gray-200">
        <h3 className="font-semibold text-gray-900 mb-4">Price Range</h3>
        <div className="px-2">
          <Slider defaultValue={[0, 50000]} max={50000} step={1000} className="mb-4" />
          <div className="flex items-center justify-between text-sm text-gray-600">
            <span>₦0</span>
            <span>₦50,000</span>
          </div>
        </div>
      </div>

      {/* Stock Status */}
      <div>
        <h3 className="font-semibold text-gray-900 mb-4">Availability</h3>
        <div className="flex items-center gap-2">
          <Checkbox id="in-stock" />
          <Label
            htmlFor="in-stock"
            className="text-sm text-gray-700 cursor-pointer hover:text-blue-600 transition-colors"
          >
            In Stock Only
          </Label>
        </div>
      </div>
    </div>
  )
}
