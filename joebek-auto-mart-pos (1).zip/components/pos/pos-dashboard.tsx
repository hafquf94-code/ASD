"use client"

import { useState } from "react"
import { ProductSearch } from "@/components/pos/product-search"
import { CategoryButtons } from "@/components/pos/category-buttons"
import { SalesCart } from "@/components/pos/sales-cart"
import { TodayStats } from "@/components/pos/today-stats"
import { RecentSales } from "@/components/pos/recent-sales"
import { SaleConfirmationModal } from "@/components/pos/sale-confirmation-modal"
import { OfflineBanner } from "@/components/pos/offline-banner"
import { NetworkStatus } from "@/components/pos/network-status"
import { CreditSaleFlow } from "@/components/easybuy/credit-sale-flow"
import { Button } from "@/components/ui/button"
import { LogOut, User, CreditCard } from "lucide-react"
import type { CartItem, Product, PaymentMethod, Sale } from "@/lib/pos-types"
import { MOCK_PRODUCTS, MOCK_SALES, MOCK_STATS } from "@/lib/pos-mock-data"

interface POSDashboardProps {
  staffName: string
  onLogout: () => void
  onOpenEasyBuy: () => void // Added prop for Easy Buy navigation
}

export function POSDashboard({ staffName, onLogout, onOpenEasyBuy }: POSDashboardProps) {
  const [cart, setCart] = useState<CartItem[]>([])
  const [isOnline, setIsOnline] = useState(true)
  const [showConfirmation, setShowConfirmation] = useState(false)
  const [showCreditSaleFlow, setShowCreditSaleFlow] = useState(false) // Added credit sale flow state
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<PaymentMethod | null>(null)
  const [recentSales, setRecentSales] = useState<Sale[]>(MOCK_SALES)
  const [stats, setStats] = useState(MOCK_STATS)

  const addToCart = (product: Product) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id)
      if (existing) {
        return prev.map((item) => (item.product.id === product.id ? { ...item, quantity: item.quantity + 1 } : item))
      }
      return [...prev, { product, quantity: 1 }]
    })
  }

  const updateQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      setCart((prev) => prev.filter((item) => item.product.id !== productId))
    } else {
      setCart((prev) => prev.map((item) => (item.product.id === productId ? { ...item, quantity } : item)))
    }
  }

  const removeFromCart = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId))
  }

  const clearCart = () => {
    setCart([])
  }

  const cartTotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0)

  const cartItemCount = cart.reduce((sum, item) => sum + item.quantity, 0)

  const handlePayment = (method: PaymentMethod) => {
    if (method === "easybuy") {
      setShowCreditSaleFlow(true)
      return
    }
    setSelectedPaymentMethod(method)
    setShowConfirmation(true)
  }

  const handleConfirmSale = (customerContact?: string) => {
    // Create new sale record
    const newSale: Sale = {
      id: `sale-${Date.now()}`,
      items: cart.map((item) => ({
        productName: item.product.name,
        quantity: item.quantity,
        price: item.product.price,
      })),
      total: cartTotal,
      paymentMethod: selectedPaymentMethod!,
      timestamp: new Date(),
      customerContact,
    }

    // Update recent sales
    setRecentSales((prev) => [newSale, ...prev.slice(0, 9)])

    // Update stats
    setStats((prev) => ({
      ...prev,
      totalSales: prev.totalSales + cartTotal,
      itemsSold: prev.itemsSold + cartItemCount,
      [selectedPaymentMethod === "cash"
        ? "cashCollected"
        : selectedPaymentMethod === "pos"
          ? "posTransfer"
          : "easyBuyCredit"]:
        prev[
          selectedPaymentMethod === "cash"
            ? "cashCollected"
            : selectedPaymentMethod === "pos"
              ? "posTransfer"
              : "easyBuyCredit"
        ] + cartTotal,
    }))
  }

  const handleSaleComplete = () => {
    clearCart()
    setShowConfirmation(false)
    setSelectedPaymentMethod(null)
  }

  const handleCreditSaleComplete = () => {
    // Create new sale record for credit sale
    const newSale: Sale = {
      id: `sale-${Date.now()}`,
      items: cart.map((item) => ({
        productName: item.product.name,
        quantity: item.quantity,
        price: item.product.price,
      })),
      total: cartTotal,
      paymentMethod: "easybuy",
      timestamp: new Date(),
    }

    setRecentSales((prev) => [newSale, ...prev.slice(0, 9)])
    setStats((prev) => ({
      ...prev,
      totalSales: prev.totalSales + cartTotal,
      itemsSold: prev.itemsSold + cartItemCount,
      easyBuyCredit: prev.easyBuyCredit + cartTotal,
    }))

    clearCart()
    setShowCreditSaleFlow(false)
  }

  // Simulate network status toggle (for demo)
  const toggleNetworkStatus = () => {
    setIsOnline((prev) => !prev)
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Offline Banner */}
      {!isOnline && <OfflineBanner />}

      {/* Header */}
      <header className="bg-card border-b border-border px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-primary flex items-center justify-center">
            <span className="text-primary-foreground font-bold text-sm">JB</span>
          </div>
          <div>
            <h1 className="font-bold text-foreground">JOEBEK AUTO-MART</h1>
            <p className="text-xs text-muted-foreground">Point of Sale</p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <Button
            variant="outline"
            size="sm"
            onClick={onOpenEasyBuy}
            className="text-orange-600 border-orange-300 hover:bg-orange-50 touch-target bg-transparent"
          >
            <CreditCard className="w-4 h-4 mr-1" />
            Easy Buy
          </Button>

          <NetworkStatus isOnline={isOnline} onToggle={toggleNetworkStatus} />

          <div className="flex items-center gap-2 text-sm">
            <User className="w-4 h-4 text-muted-foreground" />
            <span className="text-foreground font-medium">{staffName}</span>
          </div>

          <Button variant="ghost" size="sm" onClick={onLogout} className="text-muted-foreground hover:text-foreground">
            <LogOut className="w-4 h-4 mr-1" />
            Logout
          </Button>
        </div>
      </header>

      {/* Main Content - Split Screen */}
      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
        {/* Left Side - Sales Area (60%) */}
        <div className="lg:w-[60%] flex flex-col p-4 gap-4 overflow-auto">
          {/* Search */}
          <ProductSearch products={MOCK_PRODUCTS} onSelectProduct={addToCart} />

          {/* Category Quick Select */}
          <CategoryButtons products={MOCK_PRODUCTS} onSelectProduct={addToCart} />

          {/* Cart */}
          <SalesCart
            items={cart}
            total={cartTotal}
            itemCount={cartItemCount}
            onUpdateQuantity={updateQuantity}
            onRemoveItem={removeFromCart}
            onPayment={handlePayment}
          />
        </div>

        {/* Right Side - Stats & Recent Sales (40%) */}
        <div className="lg:w-[40%] bg-muted/30 p-4 flex flex-col gap-4 overflow-auto border-l border-border">
          <TodayStats stats={stats} />
          <RecentSales sales={recentSales} />
        </div>
      </div>

      {/* Sale Confirmation Modal */}
      {showConfirmation && selectedPaymentMethod && (
        <SaleConfirmationModal
          total={cartTotal}
          paymentMethod={selectedPaymentMethod}
          isOnline={isOnline}
          onConfirm={handleConfirmSale}
          onComplete={handleSaleComplete}
          onCancel={() => {
            setShowConfirmation(false)
            setSelectedPaymentMethod(null)
          }}
        />
      )}

      {showCreditSaleFlow && (
        <CreditSaleFlow
          cartTotal={cartTotal}
          onClose={() => setShowCreditSaleFlow(false)}
          onComplete={handleCreditSaleComplete}
        />
      )}
    </div>
  )
}
