"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Checkbox } from "@/components/ui/checkbox"
import { Car } from "lucide-react"

interface POSLoginProps {
  onLogin: (staffName: string) => void
}

export function POSLogin({ onLogin }: POSLoginProps) {
  const [staffId, setStaffId] = useState("")
  const [pin, setPin] = useState("")
  const [rememberDevice, setRememberDevice] = useState(false)
  const [error, setError] = useState("")

  const handlePinInput = (digit: string) => {
    if (pin.length < 4) {
      setPin((prev) => prev + digit)
      setError("")
    }
  }

  const handlePinDelete = () => {
    setPin((prev) => prev.slice(0, -1))
  }

  const handlePinClear = () => {
    setPin("")
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!staffId.trim()) {
      setError("Please enter your Staff ID")
      return
    }
    if (pin.length !== 4) {
      setError("Please enter a 4-digit PIN")
      return
    }
    // Simulated login - in production this would validate against backend
    onLogin(staffId)
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-primary/5 to-background flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-primary mb-4">
            <Car className="w-10 h-10 text-primary-foreground" />
          </div>
          <h1 className="text-3xl font-bold text-foreground">JOEBEK</h1>
          <p className="text-muted-foreground text-lg">AUTO-MART POS</p>
        </div>

        {/* Login Form */}
        <form onSubmit={handleSubmit} className="bg-card rounded-2xl shadow-lg p-6 space-y-6">
          <div className="space-y-2">
            <label htmlFor="staffId" className="text-sm font-medium text-foreground">
              Staff ID / Email
            </label>
            <Input
              id="staffId"
              type="text"
              placeholder="Enter your staff ID or email"
              value={staffId}
              onChange={(e) => {
                setStaffId(e.target.value)
                setError("")
              }}
              className="h-14 text-lg touch-target"
              autoComplete="username"
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">PIN Code</label>
            {/* PIN Display */}
            <div className="flex justify-center gap-3 mb-4">
              {[0, 1, 2, 3].map((i) => (
                <div
                  key={i}
                  className="w-14 h-14 rounded-xl border-2 border-border flex items-center justify-center text-2xl font-bold bg-muted"
                >
                  {pin[i] ? "•" : ""}
                </div>
              ))}
            </div>

            {/* Number Pad */}
            <div className="grid grid-cols-3 gap-2">
              {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((digit) => (
                <Button
                  key={digit}
                  type="button"
                  variant="outline"
                  className="h-14 text-xl font-semibold touch-target bg-transparent"
                  onClick={() => handlePinInput(digit.toString())}
                >
                  {digit}
                </Button>
              ))}
              <Button
                type="button"
                variant="outline"
                className="h-14 text-sm font-medium touch-target bg-transparent"
                onClick={handlePinClear}
              >
                Clear
              </Button>
              <Button
                type="button"
                variant="outline"
                className="h-14 text-xl font-semibold touch-target bg-transparent"
                onClick={() => handlePinInput("0")}
              >
                0
              </Button>
              <Button
                type="button"
                variant="outline"
                className="h-14 text-sm font-medium touch-target bg-transparent"
                onClick={handlePinDelete}
              >
                Delete
              </Button>
            </div>
          </div>

          {error && <p className="text-destructive text-sm text-center">{error}</p>}

          <div className="flex items-center gap-2">
            <Checkbox
              id="remember"
              checked={rememberDevice}
              onCheckedChange={(checked) => setRememberDevice(checked === true)}
            />
            <label htmlFor="remember" className="text-sm text-muted-foreground cursor-pointer">
              Remember this device
            </label>
          </div>

          <Button type="submit" className="w-full h-14 text-lg font-semibold touch-target">
            Login
          </Button>
        </form>
      </div>
    </div>
  )
}
