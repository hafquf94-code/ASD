"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { CheckCircle, Printer, MessageSquare, Banknote, CreditCard, Clock } from "lucide-react"
import type { PaymentMethod } from "@/lib/pos-types"

interface SaleConfirmationModalProps {
  total: number
  paymentMethod: PaymentMethod
  isOnline: boolean
  onConfirm: (customerContact?: string) => void
  onComplete: () => void
  onCancel: () => void
}

const PAYMENT_LABELS: Record<PaymentMethod, { label: string; icon: React.ReactNode }> = {
  cash: { label: "Cash Payment", icon: <Banknote className="w-6 h-6" /> },
  pos: { label: "POS / Transfer", icon: <CreditCard className="w-6 h-6" /> },
  easybuy: { label: "Easy Buy Credit", icon: <Clock className="w-6 h-6" /> },
}

export function SaleConfirmationModal({
  total,
  paymentMethod,
  isOnline,
  onConfirm,
  onComplete,
  onCancel,
}: SaleConfirmationModalProps) {
  const [stage, setStage] = useState<"confirm" | "complete">("confirm")
  const [customerContact, setCustomerContact] = useState("")

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("en-NG", {
      style: "currency",
      currency: "NGN",
      minimumFractionDigits: 0,
    }).format(price)
  }

  const handleConfirm = () => {
    onConfirm(customerContact || undefined)
    setStage("complete")
  }

  // Auto-close after 3 seconds when complete
  useEffect(() => {
    if (stage === "complete") {
      const timer = setTimeout(() => {
        onComplete()
      }, 3000)
      return () => clearTimeout(timer)
    }
  }, [stage, onComplete])

  const paymentInfo = PAYMENT_LABELS[paymentMethod]

  return (
    <Dialog open onOpenChange={() => stage === "confirm" && onCancel()}>
      <DialogContent className="sm:max-w-md">
        {stage === "confirm" ? (
          <>
            <DialogHeader>
              <DialogTitle className="text-xl">Confirm Sale</DialogTitle>
            </DialogHeader>

            <div className="space-y-6 py-4">
              {/* Payment Method */}
              <div className="flex items-center justify-center gap-3 p-4 bg-muted rounded-xl">
                <div className="text-primary">{paymentInfo.icon}</div>
                <span className="font-medium text-foreground">{paymentInfo.label}</span>
              </div>

              {/* Total */}
              <div className="text-center">
                <p className="text-sm text-muted-foreground mb-1">Total Amount</p>
                <p className="text-4xl font-bold text-primary">{formatPrice(total)}</p>
              </div>

              {/* Customer Contact (Optional) */}
              <div>
                <label htmlFor="customerContact" className="text-sm font-medium text-foreground">
                  Customer Phone/Email (Optional)
                </label>
                <Input
                  id="customerContact"
                  type="text"
                  placeholder="Enter phone or email for receipt"
                  value={customerContact}
                  onChange={(e) => setCustomerContact(e.target.value)}
                  className="mt-1 h-12 touch-target"
                />
              </div>

              {/* Offline Warning */}
              {!isOnline && (
                <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg">
                  <p className="text-sm text-amber-800">Sale will be queued and synced when connection restores.</p>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex gap-3">
                <Button variant="outline" className="flex-1 h-12 touch-target bg-transparent" onClick={onCancel}>
                  Cancel
                </Button>
                <Button
                  className="flex-1 h-12 bg-green-600 hover:bg-green-700 text-white touch-target"
                  onClick={handleConfirm}
                >
                  Confirm Sale
                </Button>
              </div>
            </div>
          </>
        ) : (
          <>
            <div className="py-8 text-center space-y-4">
              <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-green-100">
                <CheckCircle className="w-10 h-10 text-green-600" />
              </div>
              <h2 className="text-2xl font-bold text-foreground">Sale Complete</h2>
              <p className="text-muted-foreground">
                {!isOnline ? "Sale saved. Will sync when connection restores." : "Transaction recorded successfully."}
              </p>

              {/* Receipt Options */}
              <div className="flex justify-center gap-3 pt-4">
                <Button
                  variant="outline"
                  className="gap-2 touch-target bg-transparent"
                  onClick={() => console.log("Print receipt")}
                >
                  <Printer className="w-4 h-4" />
                  Print Receipt
                </Button>
                {customerContact && (
                  <Button
                    variant="outline"
                    className="gap-2 touch-target bg-transparent"
                    onClick={() => console.log("Send SMS")}
                  >
                    <MessageSquare className="w-4 h-4" />
                    Send SMS
                  </Button>
                )}
              </div>

              <p className="text-sm text-muted-foreground pt-2">Closing automatically in 3 seconds...</p>
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  )
}
