"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Banknote, CreditCard, Clock, TrendingUp, Package } from "lucide-react"
import type { DailyStats } from "@/lib/pos-types"

interface TodayStatsProps {
  stats: DailyStats
}

export function TodayStats({ stats }: TodayStatsProps) {
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("en-NG", {
      style: "currency",
      currency: "NGN",
      minimumFractionDigits: 0,
    }).format(price)
  }

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg">Today&apos;s Stats</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
          <div className="flex items-center gap-2">
            <Banknote className="w-5 h-5 text-green-600" />
            <span className="text-sm text-green-800">Cash</span>
          </div>
          <span className="font-bold text-green-800">{formatPrice(stats.cashCollected)}</span>
        </div>

        <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
          <div className="flex items-center gap-2">
            <CreditCard className="w-5 h-5 text-blue-600" />
            <span className="text-sm text-blue-800">POS/Transfer</span>
          </div>
          <span className="font-bold text-blue-800">{formatPrice(stats.posTransfer)}</span>
        </div>

        <div className="flex items-center justify-between p-3 bg-orange-50 rounded-lg">
          <div className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-orange-600" />
            <span className="text-sm text-orange-800">Easy Buy</span>
          </div>
          <span className="font-bold text-orange-800">{formatPrice(stats.easyBuyCredit)}</span>
        </div>

        <div className="pt-3 border-t border-border">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-primary" />
              <span className="font-medium text-foreground">Total Sales</span>
            </div>
            <span className="text-xl font-bold text-primary">{formatPrice(stats.totalSales)}</span>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Package className="w-5 h-5 text-muted-foreground" />
              <span className="text-sm text-muted-foreground">Items Sold</span>
            </div>
            <span className="font-semibold text-foreground">{stats.itemsSold}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
