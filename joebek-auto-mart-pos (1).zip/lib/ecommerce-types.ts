export type ProductCategory = "batteries" | "filters" | "engine" | "brakes" | "electrical" | "lubricants" | "accessories"

export interface EcommerceProduct {
  id: string
  name: string
  brand: string
  price: number
  stock: number
  category: ProductCategory
  image: string
  description?: string
  featured?: boolean
}

export interface CartItem {
  product: EcommerceProduct
  quantity: number
}

export interface CategoryInfo {
  id: ProductCategory
  name: string
  icon: string
  description: string
}
